$(document).ready(function(){
    // jquery datatables
    $('.datatable').DataTable({
        "scrollY":"500px",
        "scrollCollapse": true,
        "paging": false
    });
});
