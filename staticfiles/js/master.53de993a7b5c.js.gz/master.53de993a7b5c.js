$(document).ready(function(){
    // jquery datatables
    $('.datatable').DataTable({
        "scrollY":"400px",
        "scrollCollapse": false,
        "paging": truw
    });
});
